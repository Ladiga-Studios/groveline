# Database migrations

Every schema change lives here as a numbered file. Nothing gets edited after
it ships, new changes get a new file.

## Rules

1. One file per change, numbered in order: 0003_whatever_it_does.sql next.
2. Run them in order in the Supabase SQL editor. Each file runs once.
3. Never edit a migration that has already been run in production. Write a
   new one that alters what you need.
4. Keep migrations safe to re-run where possible (if not exists, drop
   constraint if exists, on conflict do nothing).

## Already run in production

- 0001_initial_schema.sql (applied via the one time reset script)
- 0002_add_drop_categories.sql

## Needs to be run

- 0003_add_profile_state.sql
- 0004_claim_removal_and_follower_emails.sql
- 0005_multi_photo_and_claim_ip.sql
- 0006_operational_platform.sql
- 0007_shipping_terms_contact_digest.sql
- 0008_shops.sql
- 0009_support_messages.sql
- 0010_follow_emails.sql
- 0011_safeguards.sql

## History

- 0001: profiles, drops, claims, waitlist, follows, newsletter subscribers,
  the atomic claim_drop function, all RLS policies, drop-photos bucket
- 0002: category column on drops for browse filtering
- 0003: state column on profiles for browse filtering
- 0004: profile emails for follower notifications, atomic remove_claim function
- 0005: photo_urls array on drops for multi-photo support, ip_address on claims for spam rate limiting
- 0006: expanded categories, pickup address and coordinates, avatar and admin on profiles, billing table, buyer-linked claims with cancel tokens and payment tracking, reports, claim_drop_v2, release_claim, increment_views, seller_stats
- 0007: shipping and fulfillment on drops, delivery and address on claims, terms acceptance, seller contact info, notification digest preference, claim_drop_v3
- 0008: shops table (one account, many seller profiles), drops/follows/subscribers repointed to shops, owns_shop helper, policies rewritten, remove_claim and seller_stats updated
- 0009: support_messages table for the support form
- 0010: follow_emails on profiles, a per-person switch for new-drop emails from followed shops
- 0011: picked_up_at, tracking, capture_mode on claims; cancel_reason and cancelled_at on drops
